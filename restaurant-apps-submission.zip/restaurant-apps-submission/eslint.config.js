import daStyle from 'eslint-config-dicodingacademy';

export default [
  daStyle,
];